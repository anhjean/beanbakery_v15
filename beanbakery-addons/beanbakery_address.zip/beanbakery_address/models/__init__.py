# -*- coding: utf-8 -*-

from . import city
from . import district
from . import ward
from . import res_partner
from . import res_country
from . import res_company